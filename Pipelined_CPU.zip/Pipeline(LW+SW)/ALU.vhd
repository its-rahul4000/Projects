	library ieee;
	use ieee.std_logic_1164.all;
	use ieee.numeric_std.all;

	entity ALU is
		port (sel		: in std_logic_vector (3 downto 0);
				A, B		: in std_logic_vector ( 15 downto 0);
				alu_en   : in std_logic;
				out_put	: out std_logic_vector ( 15 downto 0);
				imme     : in std_logic_vector (5 downto 0)
				);
	end entity;

	architecture struct of ALU is
		component mux_alu is
			port (A,B,C,D,E,F	: in std_logic_vector (15 downto 0);
					opcode: in std_logic_vector (3 downto 0);
					alu_out: out std_logic_vector (15 downto 0)
					);
		end component;
		
		component sign_ex_6 is
			port (imm_data: in std_logic_vector (5 downto 0);
				sign_ex_6_en : in std_logic;
				sign_ex_data: out std_logic_vector (15 downto 0)
				);
		end component;	
		
		signal A_sig, B_sig: std_logic_vector (15 downto 0) := (others=> 'Z');
		signal alu_out : std_logic_vector (15 downto 0) := (others=> 'Z');
		
		
		-- CODE for ADD
		function sum (A: std_logic_vector (15 downto 0); B: std_logic_vector (15 downto 0))
			return std_logic_vector is
				variable ADD: std_logic_vector (15 downto 0) := (others=>'0');
			begin
				ADD:= std_logic_vector(to_signed((to_integer(signed(A)) + to_integer(signed(B))),16));
			return ADD; 
		end function;
		
		
		-- CODE for ADDI
		function addi (A: std_logic_vector (15 downto 0); B: std_logic_vector (5 downto 0))
			return std_logic_vector is
				variable ADD_2: std_logic_vector (15 downto 0) := (others=>'0');
			begin
				ADD_2:= std_logic_vector(to_signed((to_integer(signed(A)) + to_integer(signed(B))),16));
			return ADD_2; 
		end function;
		
		-- CODE for SUB
		function subtract (A: std_logic_vector (15 downto 0); B: std_logic_vector (15 downto 0))
			return std_logic_vector is
				variable SUB: std_logic_vector (15 downto 0) := (others => '0');
			begin 
				SUB := std_logic_vector(to_signed ((to_integer(signed(A)) - to_integer(signed(B))), 16));
			return SUB;
		end function;
		
		
		-- CODE for MUL 
		function multiply (A: std_logic_vector (15 downto 0); B: std_logic_vector (15 downto 0))
			return std_logic_vector is
				variable MUL: std_logic_vector (15 downto 0) := (others => '0');
			begin 
				MUL := std_logic_vector(to_signed ((to_integer(signed(A(7 downto 0))) * to_integer(signed(B(7 downto 0)))), 16));
			return MUL;
		end function;
		
		
		--CODE for SLL 
			-- SHIFT LEFT A by B(3 downto 0)
	function shift_left_new (A: std_logic_vector(15 downto 0); B: std_logic_vector(15 downto 0))
		return std_logic_vector is
		variable SHIFT: std_logic_vector(15 downto 0) := (others => '0');
		variable shift_amt: integer;
	begin
		shift_amt := to_integer(unsigned(B(3 downto 0)));  -- Only use lower 4 bits of B
		SHIFT := std_logic_vector(shift_left(unsigned(A), shift_amt));
		return SHIFT;
	end function;
		
		
		--CODE for JRI 
		function JRI_do (A: std_logic_vector (15 downto 0); B: std_logic_vector (15 downto 0))
			return std_logic_vector is
				variable ADD: std_logic_vector (15 downto 0) := (others=>'0');
			begin
				ADD:= std_logic_vector(to_signed((to_integer(signed(A)) + to_integer(signed(B))),16));
				ADD:= std_logic_vector(to_signed((to_integer(signed(A)) + to_integer(signed(ADD))),16));
			return ADD; 
		end function;
		
		signal sum_sig,sub_sig,mul_sig, shift_sig, JRI_sig, ADDI_sig : std_logic_vector(15 downto 0) := (others=> '0');
		signal sign_exx : std_logic_vector(15 downto 0) := (others=> '0');

		begin 
		A_sig <= A;
		B_sig <= B;
		out_put <= alu_out;

		sign_ex: sign_ex_6 port map (imm_data => imme, sign_ex_6_en => '1', sign_ex_data => sign_exx); 
		
		sum_sig <= sum ( a_sig , b_sig );		--0010
		sub_sig <= subtract ( a_sig , b_sig );	--0011
		mul_sig <= multiply ( a_sig , b_sig );	--0100
		shift_sig <= shift_left_new (a_sig, b_sig); --0110
		JRI_sig <= JRI_do (a_sig, b_sig); 
		ADDI_sig <= addi (a_sig , imme); --0101
		
		mux_inst: mux_alu	port map (sum_sig,sub_sig,mul_sig,shift_sig, JRI_sig, ADDI_sig, sel,alu_out);

	end architecture;