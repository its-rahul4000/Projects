library ieee; 
use ieee.std_logic_1164.all;

entity registers is 
	port (clk: in std_logic;
--			r_sig: in std_logic;
			w_sig: in std_logic;                             
			R_d4: in std_logic_vector (15 downto 0);      
	
			R_a1, R_a2, R_a3, R_a4: in std_logic_vector (2 downto 0);
			
			R_d1, R_d2, R_d3: out std_logic_vector (15 downto 0);
			R0_out, R1_out, R2_out, R3_out, R4_out, R5_out, R6_out, R7_out: out std_logic_vector (15 downto 0)
			);
end entity; 

architecture struct of registers is 

--	signal R2,R3,R4,R5,R6,R7: std_logic_vector(15 downto 0):="0000000000000000";
--	signal R0: std_logic_vector(15 downto 0):="0000000000000101";
--	signal R1: std_logic_vector(15 downto 0):="0000000000000011";

	signal R0: std_logic_vector (15 downto 0):="0000000000000000";
	signal R1: std_logic_vector (15 downto 0):="0000000000000101";
	signal R2: std_logic_vector (15 downto 0):="0000000000000011";
	signal R3: std_logic_vector (15 downto 0):="0000000000000000";
	signal R4: std_logic_vector (15 downto 0):="0000000000000000";
	signal R5: std_logic_vector (15 downto 0):="0000000000000000";
	signal R6, R7: std_logic_vector (15 downto 0):="0000000000000000";
	
	component mux8to1 is 
		port( A,B,C,D,E,F,G,H: in std_logic_vector(15 downto 0);sel : in std_logic_vector(2 downto 0); out_reg: out std_logic_vector(15 downto 0));
	end component;
	
begin 

	P1: process(clk, R_a4, R_d4, w_sig)
		begin
			if (w_sig='1') then
				if (clk'event and clk='0') then
					case R_a4 is
						when "000" =>
							R0 <= R_d4;
						when "001" =>
							R1 <= R_d4;
						when "010" =>
							R2 <= R_d4;
						when "011" =>
							R3 <= R_d4;
						when "100" =>
							R4 <= R_d4;
						when "101" =>
							R5 <= R_d4;
						when "110" =>
							R6 <= R_d4;
						when "111" => 
							R7 <= R_d4;
						when others =>
							report "Unexpected case value detected!" severity error;
					end case;
				end if;
			end if;
	end process;
	
	M1: mux8to1 port map (R0,R1,R2,R3,R4,R5,R6,R7,R_a1,R_d1);
	M2: mux8to1 port map (R0,R1,R2,R3,R4,R5,R6,R7,R_a2,R_d2);
	M3: mux8to1 port map (R0,R1,R2,R3,R4,R5,R6,R7,R_a3,R_d3);
	
	R0_out <= R0;
	R1_out <= R1;
	R2_out <= R2;
	R3_out <= R3;
	R4_out <= R4;
	R5_out <= R5;
	R6_out <= R6;
	R7_out <= R7;
	
end architecture; 
			