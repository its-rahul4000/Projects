library ieee;
use ieee.std_logic_1164.all;
USE ieee.numeric_std.all;

entity proc is
	generic (
		 -- RAM width is 16 bits and depth is 32 locations
		 RAM_WIDTH : integer := 16;
		 RAM_DEPTH : integer := 32
	  );
	port(
	 clk : in std_logic; -- Clock signal
    rst : in std_logic; -- Reset signal
	 
	 -- Data memory (DMEM) output interface
	 rd_valid_DMEM : out std_logic; -- Indicates valid read data from DMEM
    rd_data_DMEM : out std_logic_vector(RAM_WIDTH - 1 downto 0); -- Read data from DMEM
	 
	 -- For viewing the instruction pointer externally
	 IP_view : out std_logic_vector(15 downto 0);

	 -- Output ports to view register values externally
	 R0_out, R1_out, R2_out, R3_out, R4_out, R5_out, R6_out, R7_out: out std_logic_vector (15 downto 0)
	);
end proc;

architecture rtl of proc is
	
	-- ALU component declaration
	component ALU is
		port (
			sel     : in std_logic_vector (3 downto 0); -- ALU operation selector
			A, B    : in std_logic_vector (15 downto 0); -- ALU operands
			alu_en : in std_logic; -- ALU enable signal
			out_put: out std_logic_vector (15 downto 0); -- ALU result
			imme   : in std_logic_vector (5 downto 0) -- Immediate value for some instructions
		);
	end component;

	-- Ring buffer component used for IMEM and DMEM
	component ring_buffer is
	  generic (
		 RAM_WIDTH : integer := 16;
		 RAM_DEPTH : integer := 32
	  );
	  port (
		 clk : in std_logic;
		 rst : in std_logic;
		 wr_en : in std_logic; -- Write enable
		 wr_data : in std_logic_vector(RAM_WIDTH - 1 downto 0); -- Data to write
		 rd_en : in std_logic; -- Read enable
		 rd_valid : out std_logic; -- Read valid flag
		 rd_data : out std_logic_vector(RAM_WIDTH - 1 downto 0); -- Data read from buffer
		 empty, empty_next, full, full_next : out std_logic; -- Status flags
		 fill_count : out integer range RAM_DEPTH - 1 downto 0 -- Number of elements in buffer
	  );
	end component;

	-- Memory used to fetch instruction
	component cpu_memory is 
		port (
			mem_A : in std_logic_vector (15 downto 0); -- Memory address
			mem_out : out std_logic_vector (15 downto 0); -- Data output
			mem_D3 : in std_logic_vector (15 downto 0); -- Data input (unused in fetch)
			mem_a3 : in std_logic_vector (15 downto 0); -- Write address (unused here)
			mem_w : in std_logic; -- Write enable (0 for read)
			clk : in std_logic -- Clock
		);
	end component;

	-- Register file with read and write support
	component registers is 
		port (
			clk : in std_logic;
			w_sig : in std_logic; -- Write signal
			R_d4 : in std_logic_vector (15 downto 0); -- Data to write
			R_a1, R_a2, R_a3, R_a4 : in std_logic_vector (2 downto 0); -- Register addresses
			R_d1, R_d2, R_d3 : out std_logic_vector (15 downto 0); -- Register outputs
			R0_out, R1_out, R2_out, R3_out, R4_out, R5_out, R6_out, R7_out : out std_logic_vector (15 downto 0)
		);
	end component; 
	
	-- 2-to-1 multiplexer
	component mux2to1 is
		port (
			A, B : in std_logic_vector (15 downto 0); -- Inputs
			sel : in std_logic; -- Select line
			Y : out std_logic_vector (15 downto 0) -- Output
		);
	end component;

	-- Signals for internal wiring
	signal rd_en_IMEM : std_logic := '1'; -- Always enable read from instruction memory
	signal rd_valid_IMEM : std_logic;
	signal data : std_logic_vector(RAM_WIDTH - 1 downto 0); -- Data fetched from IMEM
	signal wr_en_DMEM : std_logic := '1'; -- Always enable write to DMEM

	signal wr_data_im : std_logic_vector (15 downto 0); -- Data to write to DMEM
	signal rd_data_sig: std_logic_vector (15 downto 0); -- Data read from DMEM
	
	signal IP : std_logic_vector (15 downto 0) := (others => '0'); -- Instruction Pointer

	-- Dummy and placeholder signals
	signal dummy_sig1, dummy_sig2, dummy_sig4 : std_logic_vector (15 downto 0) := (others => '0');
	signal dummy_sig3 : std_logic_vector (2 downto 0) := (others => '0');
	signal dummy_r0, dummy_r1, dummy_r2, dummy_r3, dummy_r4, dummy_r5, dummy_r6, dummy_r7 : std_logic_vector (15 downto 0) := (others => '0');

	-- Instruction and pipeline stage signals
	signal instr_1, instr_2, instr_3, instr_4, instr_5 : std_logic_vector (15 downto 0);
	signal ID_T1, ID_T2, ID_T3 : std_logic_vector (15 downto 0);
	signal EX_T1, EX_T2, EX_T3 : std_logic_vector (15 downto 0); 
	signal MEM_T1 : std_logic_vector (15 downto 0); 
	signal WB_T1 : std_logic_vector (15 downto 0);
	signal LW_SW_sig : std_logic_vector (15 downto 0); 
	
	signal ALU_out_ex, ALU_out_mem, ALU_out_wb : std_logic_vector (15 downto 0); -- ALU outputs at each stage
	
	signal reg_wr_en : std_logic; -- Register file write enable signal
	signal mux_sel : std_logic := '0'; -- Select signal for mux2to1
	signal Mux_out : std_logic_vector (15 downto 0); -- Output from mux2to1

begin

	-- Expose internal IP and DMEM read data to top-level ports
	IP_view <= IP; 
	rd_data_DMEM <= rd_data_sig; 

	-- Data memory instance for storing LW/SW values
	DMEM: ring_buffer
		port map(
			clk => clk,
			rst => rst,
			wr_en => '1',
			wr_data => wr_data_im,
			rd_en => '1',
			rd_valid => rd_valid_DMEM,
			rd_data => rd_data_sig,
			empty => open,
			empty_next => open,
			full => open,
			full_next => open,
			fill_count => open
		);

	-- Instruction fetch from cpu_memory using current IP
	instr_fetch: cpu_memory port map (
		mem_A => IP,
		mem_out => instr_1, 
		mem_D3 => dummy_sig1 , 
		mem_a3 => dummy_sig2, 
		mem_w => '0', -- Read only
		clk => clk
	);
	
	-- Register read during decode stage
	instr_decode: registers port map (
		clk => clk, 
		w_sig => '0', -- No write here
		R_d4 => dummy_sig1, 
		R_a1 => instr_2(11 downto 9), -- Source register 1
		R_a2 => instr_2(8 downto 6),  -- Source register 2
		R_a3 => instr_2(5 downto 3),  -- Source register 3
		R_a4 => dummy_sig3, 
		R_d1 => ID_T1, 
		R_d2 => ID_T2, 
		R_d3 => ID_T3,
		R0_out => dummy_r0, R1_out => dummy_r1, R2_out => dummy_r2, R3_out => dummy_r3,
		R4_out => dummy_r4, R5_out => dummy_r5, R6_out => dummy_r6, R7_out => dummy_r7
	);

	-- ALU execution using EX stage operands and instruction
	ALU_EX: ALU port map (
		sel => instr_3(15 downto 12), -- ALU opcode
		A => EX_T2, 
		B => EX_T3, 
		ALU_en => '1', 
		out_put => ALU_out_ex,
		imme => instr_3(5 downto 0)
	);

	-- Register write during writeback stage
	instr_writeback: registers port map (
		clk => clk,
		w_sig => reg_wr_en, 
		R_d4 => Mux_out, -- Data to write
		R_a1 => dummy_sig3, 
		R_a2 => dummy_sig3, 
		R_a3 => dummy_sig3,
		R_a4 => instr_5(11 downto 9), -- Destination register
		R_d1 => dummy_sig1,
		R_d2 => dummy_sig2, 
		R_d3 => dummy_sig4,
		R0_out => R0_out, R1_out => R1_out, R2_out => R2_out, R3_out => R3_out,
		R4_out => R4_out, R5_out => R5_out, R6_out => R6_out, R7_out => R7_out
	);		

	-- Select between ALU output and DMEM output
	MUX: mux2to1 port map (
		A => ALU_out_wb,
		B => rd_data_sig,
		sel => mux_sel,
		Y => Mux_out
	); 
	
	-- Instruction fetch stage: pass instruction to decode and increment IP
	INSTR_FETCH_1: process (clk)
	begin 
		if (clk = '1' and clk'event) then
			instr_2 <= instr_1; -- Pipeline to decode
			IP <= std_logic_vector(unsigned(IP) + 1); -- Increment IP
		end if; 
	end process; 
	
	-- Instruction decode stage: pass register values to execute
	INSTR_DECODE_1: process (clk)
	begin 
		if (clk = '1' and clk'event) then 
			EX_T1 <= ID_T1; 
			EX_T2 <= ID_T2;
			EX_T3 <= ID_T3;
			instr_3 <= instr_2; -- Pipeline to execute
		end if;
	end process; 
	
	-- Execute stage: compute ALU result
	EXECUTE: process (clk)
	begin 
		if (clk = '1' and clk'event) then
			instr_4 <= instr_3; -- Pipeline to memory
			ALU_out_mem <= ALU_out_ex;
			MEM_T1 <= EX_T1; -- For SW
		end if;
	end process; 

	-- Memory stage: handle load/store and control mux for WB
	MEMORY: process (clk) 
	begin 
		if (clk = '1' and clk'event) then 
			case instr_4(15 downto 12) is
				when "0010" | "0011" | "0100" | "0101" | "0110" =>
					reg_wr_en <= '1'; -- Arithmetic/logical ops write back result
					mux_sel <= '0'; -- Select ALU output
					
				when "0001" => 
					reg_wr_en <= '0'; -- SW doesn't write back
					wr_data_im <= MEM_T1; -- Store to DMEM
					
				when "0000" =>  
					reg_wr_en <= '1'; -- LW writes back
					mux_sel <= '1'; -- Select data from memory
					
				when others =>
					reg_wr_en <= '0'; -- No write back
					mux_sel <= '0'; 
			end case; 
			instr_5 <= instr_4; -- Pipeline to WB
			ALU_out_wb <= ALU_out_mem; -- Pass ALU result to WB
		end if;
	end process; 
							
end architecture;
