transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/registers.vhd}
vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/cpu_memory.vhd}
vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/ring_buffer.vhd}
vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/Proc.vhd}
vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/mux8to1.vhd}
vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/ALU.vhd}
vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/mux_alu.vhd}
vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/sign_ex_6.vhd}
vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/mux2to1.vhd}

vcom -93 -work work {C:/Users/rahul/Downloads/Project_Pipeline(Lw+sw)/Pipeline model/Practice_TB.vhd}

vsim -t 1ps -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L fiftyfivenm -L rtl_work -L work -voptargs="+acc"  Practice_TB

add wave *
view structure
view signals
run -all
