library ieee;
use ieee.std_logic_1164.all;

entity mux2to1 is
	port (A, B: in std_logic_vector (15 downto 0);
			sel: in std_logic;
			Y: out std_logic_vector (15 downto 0));
end entity;

architecture mux of mux2to1 is

begin

	process(A, B, sel)
	begin
		case sel is
			when '0' =>
				Y <= A;
			when '1' =>
				Y <= B;
			when others => 
					NULL;
			end case;
	end process;

end mux;