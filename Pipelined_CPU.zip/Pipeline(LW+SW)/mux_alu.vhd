library ieee;
use ieee.std_logic_1164.all;

entity mux_alu is
	port (A,B,C,D,E,F	: in std_logic_vector (15 downto 0);
			opcode: in std_logic_vector (3 downto 0);
			alu_out: out std_logic_vector (15 downto 0)
			);
end entity;

architecture muxmux of mux_alu is
	
	signal out_sig: std_logic_vector (15 downto 0);
	begin
	alu_out<= out_sig; 
	
		process (A, B,C,D,E, opcode)
			begin
				case opcode is
					-- A = ADD, ADDI
					when "0010"=>
						out_sig <= A;
						
						-- B = SUB	
					when "0011" =>
						out_sig <= B;
					
					
					-- C = MUL 
					when "0100" =>
						out_sig <= C;
					
					--D = SHIFT
					when "0110" => 
						out_sig <= D;
						
					--E = JRI 
					when "0111" => 
						out_sig <= E;
						
					--F = ADDI
					when "0101" => 
					out_sig <= F;
					
					when others => 
					NULL;
				end case;
		end process; 	
	
end architecture; 