library ieee;
use ieee.std_logic_1164.all;

entity sign_ex_6 is
	port (imm_data: in std_logic_vector (5 downto 0);
			sign_ex_6_en : in std_logic;
			sign_ex_data: out std_logic_vector (15 downto 0)
			);
end entity; 

architecture stretch of sign_ex_6 is

	signal stretch: std_logic_vector (15 downto 0):= (others=> 'Z');
	signal imm_dummy: std_logic_vector (5 downto 0);
	
begin 

	imm_dummy <= imm_data;
	sign_ex_data <= stretch;
	
	process (imm_dummy,sign_ex_6_en)
	begin 
		if sign_ex_6_en = '1' then	
			if imm_dummy (5) = '0' then
				stretch <= "0000000000" & imm_dummy;
			elsif imm_dummy (5) = '1' then
				stretch <= "1111111111" & imm_dummy;
			end if;
		else 
			null;
		end if;
	end process;
	
	
end architecture;