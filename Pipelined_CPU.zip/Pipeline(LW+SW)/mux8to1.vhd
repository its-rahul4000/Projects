library ieee;
use ieee.std_logic_1164.all;

entity mux8to1 is
	port (A,B,C,D,E,F,G,H: in std_logic_vector (15 downto 0);
			sel: in std_logic_vector (2 downto 0);
			out_reg: out std_logic_vector (15 downto 0)
			);
end entity;

architecture muxmux of mux8to1 is
	
	signal sel_sig: std_logic_vector (2 downto 0);
	signal out_sig: std_logic_vector (15 downto 0);
	begin
	sel_sig <= sel; 
	out_reg<= out_sig; 
	
		process (A, B, sel_sig)
			begin
				case sel_sig is
					when "000" =>
						out_sig <= A;
					when "001" =>
						out_sig <= B;
					when "010" =>
						out_sig <= C;
					when "011" =>
						out_sig <= D;
					when "100" =>
						out_sig <= E;
					when "101" =>
						out_sig <= F;
					when "110" =>
						out_sig <= G;
					when "111" => 
						out_sig <= H;
					when others => 
					NULL;
				end case;
		end process; 	
	
end architecture; 