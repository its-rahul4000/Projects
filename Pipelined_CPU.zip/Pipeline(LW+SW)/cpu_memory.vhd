

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity cpu_memory is 
	port (mem_A: in std_logic_vector (15 downto 0);
			mem_out: out std_logic_vector (15 downto 0);
			mem_D3: in std_logic_vector (15 downto 0);
			mem_a3 : in std_logic_vector (15 downto 0);
			mem_w: in std_logic;
			clk: in std_logic
			);
end entity;

architecture my_mem of cpu_memory is 

	type regarray is array(127 downto 0) of std_logic_vector(15 downto 0);

	signal memory: regarray :=(
--		0  =>  "0000000000000000",--LW
--		1  =>  "0001000000000000",--SW
--		2  =>  "0010000001010000",--ADD
--		3  =>  "0011000001010000",--SUB
--		4  =>  "0100000001010000",--MUL
--		5 	=>  "0101000001000100",--ADDI
--		6 	=>  "0110000001010000",--SLL
--		7 	=>  "0111000000000000",--JRI

		 0 => "0010000001010000", -- ADD
		 1 => "0001001000000000", -- SW
		 2 => "0011011001010000", -- SUB
		 3 => "0100100001010000", -- MUL
		 4 => "0101101001000100", -- ADDI
		 5 => "0000011000000000", -- LW
		 6 => "0110000001010000", -- SLL
		others => x"0000");
		signal mem_out_sig: std_logic_vector (15 downto 0);
		
begin 
	
	mem_out <= mem_out_sig;
	
	mem_out_sig <= (others=>'1') when to_integer(unsigned(mem_A)) > 126 else memory(to_integer(unsigned(mem_A)));
	
--			if to_integer(unsigned(mem_A)) > 126 then
--				mem_out_sig <= (others=> '1');
--			else
--				mem_out_sig <= memory(to_integer(unsigned(mem_A)));

	
--	process (clk, mem_w,mem_a3,mem_D3)
	process (clk, mem_w)
		begin			
		if(mem_w = '1') and falling_edge(clk) then
			memory(to_integer(unsigned(mem_a3))) <= mem_D3;
		end if;
	end process;

	
end architecture;